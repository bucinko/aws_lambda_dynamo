import json
from openpyxl import load_workbook
from openpyxl.styles import Font
from termcolor import colored
from openpyxl.styles import Font, PatternFill
import psutil
import os
import sys
import time
# Load JSON data from file


filename = "sample-bom.xlsx"

        # Load the existing workbook
wb = load_workbook(filename)

request_id = input("what is the ID of request put in format IDXXX: ")



set_environments = input("Choose environment(s) (1=dev, 2=test, 3=prod) separated by commas: ")
selected_environments = set_environments.split(' ')

# List of environments
environments = {'1': 'dev', '2': 'test', '3': 'prod'}

# Loop through each selected environment
for env_number in selected_environments:
    environment = environments.get(env_number.strip())
    bom_env = environment.upper() 

    if environment:
        print("opening" + environment)
        
        
        
        
    




        with open("output.txt", "r") as file:
            json_data = json.load(file)


        # Update the data with the user input
        json_data['environment-id'] = environment
        json_data['asec-tier'] = 'at'
        json_data['is-multi-tenant'] = 'False'
        json_data['ops-exclude-patch'] = 'S1'
        json_data['is-appliance'] = 'False'
        json_data['is-appliance'] = 'False'


        # Write the updated data back to the JSON file
        with open('output.txt', 'w') as file:
            json.dump(json_data, file, indent=4)

        print("JSON file has been updated.")

        with open("output.txt", "r") as file:
            json_data = json.load(file)



        for key, value in json_data.items():
            print(colored(key, 'blue'), ":", colored(value, 'green'))
            


        # Select the active worksheet
        #ws = wb.active

        # Specify the sheet name you want to access
        sheet_name = bom_env+"-BOM"

        # Check if the sheet name exists in the workbook
        if sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            wb.active = wb.index(ws)
            print(f"Sheet '{sheet_name}' is selected.")
            # Now you can work with the selected sheet (ws)
        else:
            print(f"Sheet '{sheet_name}' does not exist in the workbook.")

        ws.insert_rows(53)

        # delete ops-time-schedule
        # Define the range of rows to iterate over
        min_row = 15
        max_row = 20

        # Define the values to check for hiding rows
        values_to_hide = ["ops-uptime-schedule", ""]

        # Iterate over rows in the specified range
        for row_num in range(min_row, max_row + 1):
            cell_value = ws.cell(row=row_num, column=1).value  # Assuming the value is in the first column
            if cell_value in values_to_hide:
                ws.row_dimensions[row_num].hidden = True

        # # Set font size to 10 for the entire worksheet
        # for row in ws.iter_rows():
        #     for cell in row:
        #         cell.font = Font(size=10)

        # Iterate through each row in the Excel sheet



        # Iterate over rows in the Excel sheet
        for row in ws.iter_rows(min_row=6, max_row=20, min_col=1, max_col=2):
            field_name = row[0].value
            if field_name in json_data:
                # Check if the value in JSON is null, if yes, set it to "N/A" in Excel and fill background color to yellow
                if json_data[field_name] is None:
                    row[1].value = "N/A"
                    yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid') # Yellow color code
                    row[1].fill = yellow_fill
                    row[1].font = Font(color="000000")  # Set font color to black
                else:
                    row[1].value = json_data[field_name]
                    row[1].font = Font(size=10)

        # Save the workbook with the updated values and font size
        save_file_name = f"{request_id}-BOM_{json_data['apms-id']}.xlsx"
        wb.save(save_file_name)
        filename = save_file_name

        # Load the existing workbook
        wb = load_workbook(save_file_name)



else:
    print(f"Invalid environment number: {env_number}. Please choose 1, 2, or 3.")