# Get user input for environment
set_environments = input("Choose environment(s) (1=dev, 2=test, 3=prod) separated by commas: ")
selected_environments = set_environments.split(' ')

# List of environments
environments = {'1': 'dev', '2': 'test', '3': 'prod'}

# Loop through each selected environment
for env_number in selected_environments:
    environment = environments.get(env_number.strip())
    if environment:
        print("opening" + environment)
    else:
        print(f"Invalid environment number: {env_number}. Please choose 1, 2, or 3.")