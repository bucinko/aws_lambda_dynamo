import requests

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate, br',
    'Referer': 'https://takeda.service-now.com/nav_to.do?uri=%2Fcmdb_ci_business_app.do%3Fsys_id%3D6deec7711b79f998c84da712604bcbe3%26sysparm_domain%3Dnull%26sysparm_domain_scope%3Dnull',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'iframe',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-User': '?1',
    'Sec-GPC': '1',
    'Connection': 'keep-alive',
    'Cookie': 'glide_user_route=glide.9e92ef8724074779c0fe5368e6bab983; glide_sso_id=e8ee1c5d1bb00410eec5baafdc4bcb86; BIGipServerpool_takeda=642635650e03ac2110120f8a68e0d792; JSESSIONID=C022D8880540C75CDE4229795CC30BB9; __CJ_g_startTime=%221699908972212%22; glide_language=en; glide_user_activity=U0N2M18xOlQ2WEJwaW5lbEVpaXJIckhSa1A0SS9xR2FucUVLL2hadlA1T0lSN2xkMk09Om15UDBZbWsrWVJFTGtjUlZ5QWxMTGpKdHNQZlBNOVNEWk16Ui9CdDZlS0U9; glide_session_store=A78463A01BEA7DD89920EC602A4BCB85; __CJ_tabs2_section_cmdb_ci_business_app=%220%22; __CJ_tabs2_list_cmdb_ci_business_app=%220%22'
}

url = 'https://takeda.service-now.com/cmdb_ci_business_app.do?sys_id=6deec7711b79f998c84da712604bcbe3&sysparm_domain=null&sysparm_domain_scope=null'

response = requests.get(url, headers=headers)
print(response.json())  # This will show the HTML content retrieved from the URL
