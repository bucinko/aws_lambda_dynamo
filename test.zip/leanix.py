import requests
import json
from termcolor import colored
from bs4 import BeautifulSoup

secret_bearer = "Bearer eyJraWQiOiI0ODQxM2FmNzc3YTEyZmJlNTVlMmYxNzQ5ODg4ODQ0MyIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJtYXJ0aW4uYW50YWxpY0B0YWtlZGEuY29tIiwicHJpbmNpcGFsIjp7ImlkIjoiOGUxZWUyOWQtYjQxZi00YzdjLTg3MzgtNzZkZWEwOTc3MDQ0IiwidXNlcm5hbWUiOiJtYXJ0aW4uYW50YWxpY0B0YWtlZGEuY29tIiwicm9sZSI6IkFDQ09VTlRVU0VSIiwic3RhdHVzIjoiQUNUSVZFIiwiYWNjb3VudCI6eyJpZCI6Ijc4NDQ5ZTRmLWQ4N2QtNDE1OS1iMTFlLWEzZWQyM2Q1ZTNiMSIsIm5hbWUiOiJUYWtlZGEifSwicGVybWlzc2lvbiI6eyJpZCI6Ijk1NzFjOGI2LTYzMzEtNDBjMy1iYTgwLTEwOWNhOWI2OTY2NyIsIndvcmtzcGFjZUlkIjoiYmU5NDBjZDEtYTZiYS00MTRmLWIyZWItNDQyZTZiZDBmNjhjIiwid29ya3NwYWNlTmFtZSI6IlRha2VkYVByb2R1Y3Rpb24iLCJyb2xlIjoiTUVNQkVSIiwiY3VzdG9tZXJSb2xlcyI6bnVsbCwiYWNjZXNzQ29udHJvbEVudGl0aWVzIjpudWxsLCJzdGF0dXMiOiJBQ1RJVkUiLCJhc1VzZXIiOm51bGx9fSwiaXNzIjoiaHR0cHM6Ly91cy1zdmMubGVhbml4Lm5ldCIsImp0aSI6IjhmMjUxMWY0LWUxZDctNGU2Ny1iMTM3LTFkYzFjNDg2OTkxNiIsImV4cCI6MTcwODYxNDk1MywiaW5zdGFuY2VVcmwiOiJodHRwczovL3Rha2VkYS5sZWFuaXgubmV0IiwicmVnaW9uIjoiZWFzdHVzIn0.aG5nAB55YxJhRpm_wZEy9VVZf-tk-m1XoUGS0Wu9Osr1Ag1MZNv_ySafM97-OmGHDHgv5fKcpD4ZjO93Nzwa-aNFSnif9uAZSMaSfdbGUiFHRnmEzc8PSl8NK24xa16III7y-zISzzHPpoz-mqyrJHfotoRIrU3noq7x9oRNtXPapxhFk0fuxx9FzNq0V1UOuQCjFrlDArK4SXdafKByjeadjuB0qZT7XsnMf-6ReWiLSkkMW7f_emqZpK55s_p3cKTcHD7c61BA5jPl6nzhySi66qhRpbNkwCBNHzcjrAAdEzyzlSGJmiyxMqsNdBaMBXh5edP5lQldxSOBfIFzBg"

url = "https://takeda.leanix.net/services/pathfinder/v1/suggestions"
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br",
    "Authorization": secret_bearer,
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "Referer": "https://takeda.leanix.net/TakedaProduction/dashboard/b0b037a9-0642-433f-ac51-8dae55d8a588",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "Sec-GPC": "1",
    "TE": "trailers"
}


# User input for APMS value
user_input = input("Enter the APMS value (input in format APMS-xxxxx): ")

params = {
    "q": user_input,
    "count": "26",
    "perType": "true"
}


# Initialize variables
apms_object_id = None
apms_value = None
displayName = None

response = requests.get(url, headers=headers, params=params)
data = response.json()
print(data)
#print(response.json())  # or use response.json() if expecting JSON response

# for item in response.json():
#     print(item)

# Search for the user-input APMS value in the JSON
print(data['data'])
for item in data['data']:
    if item['type'] == 'Application':
        for suggestion in item['suggestions']:
            if 'displayName' in suggestion:
                displayName = suggestion['displayName']
            for reason in suggestion['reasons']:
                if reason['value'] == user_input:
                    apms_object_id = suggestion['objectId']
                    apms_value = reason['value']
                    break
                
                
if apms_object_id and apms_value:
    print("APMS Object ID:", apms_object_id)
    print("APMS Value:", apms_value)
else:
    print("APMS value not found in the JSON data.")



print("now query subscriptions: ")

fs_id = apms_object_id
url = 'https://takeda.leanix.net/services/pathfinder/v1/graphql?_=FS_DATA&fsId=' + fs_id
leanix_data = {
    "query":"query{factSheet:factSheet(id:\"%s\" markAsViewed:true){...on Application{rev type naFields permissions{self create read update delete}displayName name description category id fullName type tags{id name color description tagGroup{id shortName mode name mandatory}}subscriptions{edges{node{id user{id firstName lastName displayName email technicalUser permission{role status}}type roles{id name description comment subscriptionType restrictToFactSheetTypes}createdAt}}}status level createdAt updatedAt lxState qualitySeal ApplicationLifecycle:lifecycle{asString phases{phase startDate milestoneId}}functionalSuitabilityDescription technicalSuitabilityDescription functionalSuitability technicalSuitability businessCriticality release businessCriticalityDescription alias orderingState UAMSApplicationClassification UAMSGeneralComments UAMSIsApplicationAAGlobal UAMSOriginalScope UAMSServiceBranding UAMSServiceClass UAMSServiceGroup UAMSServiceStartDate UAMSSupportType UAMSTimezoneOfSLA UAMSUAMSStatus UAMSVendor UAMSVendorType UAMSMainUAMScontactperson CostCloudSpend CostServer CostDepreciation CostTotalCost CostCP080201ASOUAMSMRP CostCP080201ASOMRP CostCP081102LicenseMRP CostCP080202AppTestMRP CostCP081101SWMFMRP CostCP080101SaasMRP CostCP080201ASOUpdate CostCP081102LicenseUpdate CostCP080202AppTestUpdate CostCP081101SWMFUpdate CostCP080101SaasUpdate activeStartDate N2Manager N2Org lastUpdate FujiIntegrationLeadDecisionV2 FujiRollUpViewV2 aggregatedObsolescenceRisk mitigatedObsolescenceRiskPercentage obsolescenceMissingDataPercentage unaddressedObsolescenceRiskPercentage BusinessImpactAnalysisDate ResiliencyPlanDate ResiliencyTestDate CostDBConsumption overallRating EAcomments lxCatalogStatus lxProductCategory lxHostingType lxHostingDescription lxSsoProvider lxStatusSSO applicationId{externalId comment externalUrl status}externalId{externalId comment externalUrl status}serviceNowExternalId{externalId comment externalUrl status}signavioGlossaryItemId{externalId comment externalUrl status}leanixV3IdApplication{externalId comment externalUrl status}lxSiId{externalId comment externalUrl status}lxCatalogId{externalId comment externalUrl status}relToParent(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Application{ApplicationLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relToChild(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Application{ApplicationLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relToRequires(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Application{ApplicationLifecycle:lifecycle{asString phases{phase startDate}}}...on UserGroup{UserGroupLifecycle:lifecycle{asString phases{phase startDate}}}...on TechPlatform{TechPlatformLifecycle:lifecycle{asString phases{phase startDate}}}...on Service{ServiceLifecycle:lifecycle{asString phases{phase startDate}}}...on ITComponent{ITComponentLifecycle:lifecycle{asString phases{phase startDate}}}...on Provider{ProviderLifecycle:lifecycle{asString phases{phase startDate}}}...on TechnicalStack{TechnicalStackLifecycle:lifecycle{asString phases{phase startDate}}}...on BusinessCapability{BusinessCapabilityLifecycle:lifecycle{asString phases{phase startDate}}}...on DigitalProduct{DigitalProductLifecycle:lifecycle{asString phases{phase startDate}}}...on governanceRecord{GovernanceRecordLifecycle:lifecycle{asString phases{phase startDate}}}...on Project{ProjectLifecycle:lifecycle{asString phases{phase startDate}}}...on DataObject{DataObjectLifecycle:lifecycle{asString phases{phase startDate}}}...on Interface{InterfaceLifecycle:lifecycle{asString phases{phase startDate}}}...on valueStream{ValueStreamLifecycle:lifecycle{asString phases{phase startDate}}}...on Process{ProcessLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relToRequiredBy(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Application{ApplicationLifecycle:lifecycle{asString phases{phase startDate}}}...on UserGroup{UserGroupLifecycle:lifecycle{asString phases{phase startDate}}}...on TechPlatform{TechPlatformLifecycle:lifecycle{asString phases{phase startDate}}}...on Service{ServiceLifecycle:lifecycle{asString phases{phase startDate}}}...on ITComponent{ITComponentLifecycle:lifecycle{asString phases{phase startDate}}}...on Provider{ProviderLifecycle:lifecycle{asString phases{phase startDate}}}...on TechnicalStack{TechnicalStackLifecycle:lifecycle{asString phases{phase startDate}}}...on BusinessCapability{BusinessCapabilityLifecycle:lifecycle{asString phases{phase startDate}}}...on DigitalProduct{DigitalProductLifecycle:lifecycle{asString phases{phase startDate}}}...on governanceRecord{GovernanceRecordLifecycle:lifecycle{asString phases{phase startDate}}}...on Project{ProjectLifecycle:lifecycle{asString phases{phase startDate}}}...on DataObject{DataObjectLifecycle:lifecycle{asString phases{phase startDate}}}...on Interface{InterfaceLifecycle:lifecycle{asString phases{phase startDate}}}...on valueStream{ValueStreamLifecycle:lifecycle{asString phases{phase startDate}}}...on Process{ProcessLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relToSuccessor(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Application{ApplicationLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relToPredecessor(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Application{ApplicationLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToUserGroup(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil functionalSuitability numberOfUsers description usageType permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on UserGroup{UserGroupLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToDataObject(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil usage description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on DataObject{DataObjectLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToITComponent(first:5 facetFilters:[{facetKey:\"category\",keys:[\"__missing__\"]}]){permissions{self create read update delete}edges{node{id activeFrom activeUntil costTotalAnnual technicalSuitability description serviceLevel obsolescenceRiskStatus obsolescenceRiskComment permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on ITComponent{ITComponentLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}...on ITComponent{relITComponentToTechPlatform(first:5 facetFilters:{facetKey:\"relTechPlatformToApplication\" keys:[\"9512657b-8531-4550-840f-594fd55c709e\"]}){edges{node{factSheet{type displayName}}}}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToITComponent_software:relApplicationToITComponent(first:5 facetFilters:[{facetKey:\"category\",keys:[\"software\"]}]){permissions{self create read update delete}edges{node{id activeFrom activeUntil costTotalAnnual technicalSuitability description serviceLevel obsolescenceRiskStatus obsolescenceRiskComment permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on ITComponent{ITComponentLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}...on ITComponent{relITComponentToTechPlatform(first:5 facetFilters:{facetKey:\"relTechPlatformToApplication\" keys:[\"9512657b-8531-4550-840f-594fd55c709e\"]}){edges{node{factSheet{type displayName}}}}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}, relApplicationToITComponent_hardware:relApplicationToITComponent(first:5 facetFilters:[{facetKey:\"category\",keys:[\"hardware\"]}]){permissions{self create read update delete}edges{node{id activeFrom activeUntil costTotalAnnual technicalSuitability description serviceLevel obsolescenceRiskStatus obsolescenceRiskComment permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on ITComponent{ITComponentLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}...on ITComponent{relITComponentToTechPlatform(first:5 facetFilters:{facetKey:\"relTechPlatformToApplication\" keys:[\"9512657b-8531-4550-840f-594fd55c709e\"]}){edges{node{factSheet{type displayName}}}}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}, relApplicationToITComponent_service:relApplicationToITComponent(first:5 facetFilters:[{facetKey:\"category\",keys:[\"service\"]}]){permissions{self create read update delete}edges{node{id activeFrom activeUntil costTotalAnnual technicalSuitability description serviceLevel obsolescenceRiskStatus obsolescenceRiskComment permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on ITComponent{ITComponentLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}...on ITComponent{relITComponentToTechPlatform(first:5 facetFilters:{facetKey:\"relTechPlatformToApplication\" keys:[\"9512657b-8531-4550-840f-594fd55c709e\"]}){edges{node{factSheet{type displayName}}}}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToProject(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Project{ProjectLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relProviderApplicationToInterface(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Interface{InterfaceLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relConsumerApplicationToInterface(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Interface{InterfaceLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToProcess(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on Process{ProcessLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}constrainingRelations{relations{id type factSheet{id displayName type}}totalCounts{type totalCount}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToBusinessCapability(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil supportType functionalSuitability description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on BusinessCapability{BusinessCapabilityLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}constrainingRelations{relations{id type factSheet{id displayName type}}totalCounts{type totalCount}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToTechPlatform(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on TechPlatform{TechPlatformLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToGovernanceRecord(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on governanceRecord{GovernanceRecordLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}relApplicationToDigitalProduct(first:5){permissions{self create read update delete}edges{node{id activeFrom activeUntil description permissions{self create read update delete}factSheet{id displayName fullName description type category permissions{self create read update delete}subscriptions{edges{node{id type user{id displayName technicalUser email}}}}...on DigitalProduct{DigitalProductLifecycle:lifecycle{asString phases{phase startDate}}}tags{id name description color tagGroup{id shortName name}}}}}pageInfo{startCursor endCursor hasNextPage hasPreviousPage}totalCount}}}}"%fs_id,"variables":{}
}


response = requests.post(url, headers=headers, json=leanix_data)

#print(response.json())
data = response.json()
print("ServiceNowExternalID :"+data['data']['factSheet']['serviceNowExternalId']['externalId'])
data_experts = data['data']['factSheet']['subscriptions']

responsible_person = None
observer = None
subject_matter_experts = []
application_managers = []
service_ci_id = None


for item in data_experts['edges']:
    node_data = item['node']
    roles = node_data.get('roles', [])
    for role in roles:
        if role.get('name') == 'Subject Matter Expert':
            subject_matter_experts.append({
                'displayName': node_data['user']['displayName'],
                'email': node_data['user']['email'],
                'comment': role['comment']
            })
        elif role.get('name') == 'Application Manager':
            application_managers.append({
                'displayName': node_data['user']['displayName'],
                'email': node_data['user']['email'],
                'comment': role['comment']
            })

# Print details of Subject Matter Experts
print("Subject Matter Experts:")
for expert in subject_matter_experts:
    print("Name:", expert['displayName'])
    print("Email:", expert['email'])
    print("Comment:", expert['comment'])

# Print details of Application Managers
print("\nApplication Managers:")
for manager in application_managers:
    print("Name:", manager['displayName'])
    print("Email:", manager['email'])
    print("Comment:", manager['comment'])
    
    

url = "https://takeda.leanix.net/services/pathfinder/v1/graphql?_=FS_DATA&fsId=%s" +apms_object_id


response = requests.post(url, headers=headers, json=leanix_data)

json_data = response.json()
data = json_data['data']['factSheet']['tags']
#print(data)

target_short_name = 'RecoveryTier'
#print("target short name: \n"+target_short_name)

recovery_tier = next((item['name'] for item in data if item['tagGroup']['shortName'] == target_short_name), None)

if recovery_tier:
    print("Matching Name:", recovery_tier)
else:
    print(f"No matching 'shortName' found for '{target_short_name}' in the data.")


data = {
    "architectName": "Martin Antalic",
    "apms-id": apms_value,
    "it-technical-owner": subject_matter_experts[0]['email'],
    "application-owner": application_managers[0]['email'],
    "application-name" : displayName,
    "recovery-tier"    : recovery_tier,
    "service-ci-id"    : service_ci_id
    
}

with open("output.txt", "w") as file:
    json.dump(data, file, indent=4, sort_keys=True)

# Open the file in write mode ('w')
# with open("output.txt", "w") as file:
#     file.write(f"Martin Antalic\n")
#     file.write(f"{apms_value}\n")
    
#     if matching_name:
#         file.write(f"Matching Name {matching_name}")
#     # Write Subject Matter Experts details
#     file.write("Subject Matter Experts:\n")
#     for expert in subject_matter_experts:
#         # file.write(f"Name: {expert['displayName']}\n")
#         file.write(f"Email: {expert['email']}\n")
    
#     # Write details of Application Managers
#     file.write("\nApplication Managers:\n")
#     for manager in application_managers:
#         # file.write(f"Name: {manager['displayName']}\n")
#         file.write(f"Email: {manager['email']}\n")


